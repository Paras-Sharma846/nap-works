const { body } = require('express-validator');

exports.signupValidation = [
  body('name').notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
];

exports.loginValidation = [
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required'),
];

exports.createPostValidation = [
  body('userId').isMongoId().withMessage('Valid userId is required'),
  body('postName').notEmpty().withMessage('Post name is required'),
  body('description').notEmpty().withMessage('Description is required'),
  body('tags').optional().isArray().withMessage('Tags should be an array of strings'),
  body('imageUrl').optional().isURL().withMessage('Valid image URL is required'),
];