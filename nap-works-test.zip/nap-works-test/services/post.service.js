const {Post} = require('../models/post.model');

exports.createPostService = async (postData) => {
  try {
    const newPost = new Post(postData);
    await newPost.save();
    return newPost;
  } catch (err) {
    throw new Error(err.message);
  }
};

exports.fetchFilteredPosts = async ({ searchText, startDate, endDate, tags, page, limit, userId }) => {
    const query = { userId };
  
    if (searchText) {
      query.$or = [
        { postName: { $regex: searchText, $options: 'i' } },
        { description: { $regex: searchText, $options: 'i' } }
      ];
    }
  
    if (startDate || endDate) {
      query.uploadTime = {};
      if (startDate) query.uploadTime.$gte = new Date(startDate);
      if (endDate) query.uploadTime.$lte = new Date(endDate);
    }
  
    if (tags) {
      const tagsArray = Array.isArray(tags) ? tags : tags.split(',');
      query.tags = { $in: tagsArray };
    }
  
    const skip = (page - 1) * limit;
  
    const posts = await Post.find(query)
      .sort({ uploadTime: -1 })
      .skip(skip)
      .limit(Number(limit));
  
    const total = await Post.countDocuments(query);
  
    return {
      posts,
      total,
      currentPage: Number(page),
      totalPages: Math.ceil(total / limit)
    };
  };
  