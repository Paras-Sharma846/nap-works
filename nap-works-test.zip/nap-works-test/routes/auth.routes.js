const express = require('express');
const { signup, login } = require('../controllers/auth.controller');
const validate = require('../middlewares/validate');
const { signupValidation, loginValidation } = require('../helpers/auth.validator');

const router = express.Router();

router.post('/signup', signupValidation, validate, signup);
router.post('/login', loginValidation, validate, login);

module.exports = router;
