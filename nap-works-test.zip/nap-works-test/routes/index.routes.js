const authRouter = require('./auth.routes');
const postRouter = require('./post.routes');

module.exports = {
  authRouter,
  postRouter,
};
