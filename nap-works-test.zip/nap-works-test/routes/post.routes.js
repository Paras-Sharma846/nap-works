const express = require('express');
const { createPost,getFilteredPosts } = require('../controllers/post.controller');
const { createPostValidation } = require('../helpers/auth.validator');
const validate = require('../middlewares/validate');
const authMiddleware = require('../middlewares/authMiddleware');

const router = express.Router();

router.post('/', authMiddleware, createPostValidation, validate, createPost);
router.get('/get-post', authMiddleware, getFilteredPosts);

module.exports = router;
