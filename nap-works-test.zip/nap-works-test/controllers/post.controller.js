const { createPostService, fetchFilteredPosts } = require('../services/post.service');
const sendResponse = require('../helpers/responseHelper');

// create post
exports.createPost = async (req, res) => {
  try {
    const newPost = await createPostService(req.body);
    sendResponse(res, 201, 'Post created successfully', newPost);
  } catch (err) {
    sendResponse(res, 400, err.message);
  }
};

// get post
exports.getFilteredPosts = async (req, res) => {
    try {
      const { searchText, startDate, endDate, tags, page = 1, limit = 10 } = req.query;
  
      const result = await fetchFilteredPosts({
        userId: req.user._id,
        searchText,
        startDate,
        endDate,
        tags,
        page,
        limit
      });
  
      return sendResponse(res, 200, 'Posts fetched successfully', result);
    } catch (error) {
      return sendResponse(res, 500, error.message);
    }
  };
  