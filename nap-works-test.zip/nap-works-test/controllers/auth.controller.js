// controllers/auth.controller.js
const { registerUser, loginUser } = require('../services/auth.service');
const sendResponse = require('../helpers/responseHelper'); 

exports.signup = async (req, res) => {
  try {
    const result = await registerUser(req.body);
    sendResponse(res, 201, 'User registered successfully', result);
  } catch (err) {
    sendResponse(res, 400, err.message);
  }
};

exports.login = async (req, res) => {
  try {
    const result = await loginUser(req.body);
    sendResponse(res, 200, 'Login successful', result); 
  } catch (err) {
    sendResponse(res, 401, err.message);
  }
};
