require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const logger = require('./middlewares/logger');
const { authRouter, postRouter } = require('./routes/index.routes');

const app = express();

// Middleware
app.use(express.json());
app.use(logger);

// Routes
app.use('/api/auth', authRouter); 
app.use('/api/posts', postRouter);

// Start server
const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});
